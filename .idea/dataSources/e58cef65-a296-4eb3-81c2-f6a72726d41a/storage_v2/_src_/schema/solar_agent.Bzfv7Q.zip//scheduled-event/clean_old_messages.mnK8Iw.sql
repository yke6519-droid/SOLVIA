create definer = root@localhost event clean_old_messages on schedule
    every '1' DAY
        starts '2026-07-09 03:00:00'
    enable
    do
    DELETE FROM message_store
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 10 DAY);

